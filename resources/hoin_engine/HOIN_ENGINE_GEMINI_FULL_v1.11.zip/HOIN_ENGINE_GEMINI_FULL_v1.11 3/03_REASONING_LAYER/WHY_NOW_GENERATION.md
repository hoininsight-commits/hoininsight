# WHY_NOW_GENERATION.md

WHY_NOW STRUCTURE

1. What changed in data state
2. Why existing narrative is insufficient
3. Where capital is reallocating
4. Why this timing is non-repeatable

FINAL RULE
If timing cannot be justified → do not output.
