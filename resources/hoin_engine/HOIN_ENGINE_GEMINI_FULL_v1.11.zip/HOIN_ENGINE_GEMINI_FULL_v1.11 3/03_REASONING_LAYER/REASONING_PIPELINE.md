# REASONING_PIPELINE.md

PIPELINE OVERVIEW

INPUT
- Macro / Market / Policy / Structural data

PROCESS
1. Signal aggregation
2. Threshold crossing detection
3. Multi-signal confirmation
4. Capital behavior validation

OUTPUT
- WHY_NOW explanation only

NO OUTPUT
- If capital movement is not observable.
