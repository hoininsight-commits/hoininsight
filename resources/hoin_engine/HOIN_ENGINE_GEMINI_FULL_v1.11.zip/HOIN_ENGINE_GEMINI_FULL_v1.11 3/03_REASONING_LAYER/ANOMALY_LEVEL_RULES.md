# ANOMALY_LEVEL_RULES.md

L1: Noise
- Single signal
- No capital confirmation

L2: Attention
- Multiple signals
- Early capital probing

L3: Capitalization
- Sustained inflow
- Relative strength persistence

L4: Lock-in
- Capital fixation
- Exit cost formation
