# HOIN_ENGINE_GEMINI_FULL_CANONICAL

This package is a canonical reasoning transplant of HOIN ENGINE.

02_CANONICAL_DOCS must be populated with:
- BASELINE_SIGNALS_v1.0.md
- DATA_COLLECTION_MASTER_v1.8.md
- ANOMALY_DETECTION_LOGIC_v1.11.md

These files must be original and unmodified.

Purpose:
To reproduce identical WHY_NOW analysis logic across AI systems.
