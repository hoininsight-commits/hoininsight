from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import pandas as pd
import yaml

from src.utils.registry.loader import load_datasets

@dataclass
class SchemaCheckResult:
    ok: bool
    lines: list[str]

def _load_schema(base_dir: Path, schema_version: str) -> Dict:
    schema_file = base_dir / "registry" / "schemas" / f"{schema_version}.yml"
    if not schema_file.exists():
        raise FileNotFoundError(f"schema file not found: {schema_file.as_posix()}")
    return yaml.safe_load(schema_file.read_text(encoding="utf-8"))

def _missing_cols(df_cols: List[str], required: List[str]) -> List[str]:
    s = set(df_cols)
    return [c for c in required if c not in s]

def run_schema_checks(base_dir: Path, target_categories: list[str] = None) -> SchemaCheckResult:
    reg = base_dir / "registry" / "datasets.yml"
    all_datasets = load_datasets(reg)
    
    if target_categories:
        datasets = [ds for ds in all_datasets if ds.enabled and ds.category in target_categories]
    else:
        datasets = [ds for ds in all_datasets if ds.enabled]

    ok = True
    lines: list[str] = []
    for ds in datasets:
        schema = _load_schema(base_dir, ds.schema_version)
        required = schema.get("required_columns", [])
        curated = base_dir / ds.curated_path

        if not curated.exists():
            if ds.soft_fail:
                lines.append(f"[SKIP] schema({ds.dataset_id}): missing curated file (soft_fail)")
            else:
                ok = False
                lines.append(f"[MISS] curated({ds.dataset_id}): {curated.as_posix()}")
            continue

        try:
            df = pd.read_csv(curated)
            miss = _missing_cols(list(df.columns), list(required))
            if miss:
                ok = False
                lines.append(f"[FAIL] schema({ds.dataset_id}): missing={miss}")
            else:
                lines.append(f"[OK] schema({ds.dataset_id}): {ds.schema_version}")
        except Exception as e:
            # If file exists but is unreadable, that is a FAIL unless soft_fail? 
            # Usually unreadable means corrupted. Let's treat as FAIL or soft fail depending on policy.
            # Ideally if soft_fail is True, we shouldn't crash pipeline for this.
            if ds.soft_fail:
                lines.append(f"[SKIP] schema({ds.dataset_id}): error reading file: {e}")
            else:
                ok = False
                lines.append(f"[FAIL] schema({ds.dataset_id}): error reading file: {e}")

    return SchemaCheckResult(ok=ok, lines=lines)
