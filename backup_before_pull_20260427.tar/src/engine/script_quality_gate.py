
import json
import re
from typing import Dict, List, Optional

class ScriptQualityGate:
    """[TASK #091] SCRIPT QUALITY GATE
    생성된 스크립트의 품질을 5개 항목으로 평가하고 PASS/HOLD/DROP 결정
    """
    
    def __init__(self):
        from src.core.gemini_client import GeminiClient
        self.gemini = GeminiClient()
        
    def evaluate(self, content: Dict) -> Dict:
        """스크립트 평가 및 최종 상태 결정 (Dual-Stage 적용)"""
        script = content.get("script", "")
        
        # [STAGE 1] Deterministic Evaluation (필수 구조 체크)
        det_report = self._evaluate_deterministically(content)
        
        # [STAGE 2] Gemini Evaluation (TIER 3 - 선택적 품질 평가)
        prompt = self._build_evaluation_prompt(content)
        gemini_eval = {}
        try:
            # TIER 3 호출 (실패 시 즉각 fallback)
            res = self.gemini.call_json_controlled(prompt, agent="QUALITY_GATE", tier=3)
            if res:
                gemini_eval = res
            else:
                print("  ⚠️ Quality Gate Stage 2 (Gemini) 응답 없음. Deterministic 점수 사용.")
        except Exception as e:
            print(f"  ⚠️ Quality Gate Stage 2 (Gemini) 실패: {e}. Deterministic 점수 사용.")

        # 점수 병합
        report = {
            "hook_score": gemini_eval.get("hook_score", det_report["hook_score"]),
            "why_now_score": gemini_eval.get("why_now_score", det_report["why_now_score"]),
            "scenario_score": gemini_eval.get("scenario_score", det_report["scenario_score"]),
            "theme_score": gemini_eval.get("theme_score", det_report["theme_score"]),
            "action_score": gemini_eval.get("action_score", det_report["action_score"]),
        }
        
        total_score = sum(report.values()) / len(report)
        report["total_score"] = round(total_score, 1)
        
        # 최종 상태 결정
        status = "PASS"
        if total_score >= 4.0: status = "PASS"
        elif total_score >= 3.0: status = "HOLD"
        else: status = "DROP"
        
        # 하드 규칙 적용 (결정론적 검사 결과가 DROP이면 강제 DROP)
        if det_report["status"] == "DROP":
            status = "DROP"
            report["drop_reason"] = det_report["drop_reason"]
        else:
            report["drop_reason"] = None

        report["status"] = status
        return report

    def _evaluate_deterministically(self, content: Dict) -> Dict:
        """결정론적 지표 검사 (새로운 7단계 DNA 대응)"""
        script = content.get("script", "")
        script_lower = script.lower()
        
        scores = {
            "hook_score": 3,
            "why_now_score": 3,
            "scenario_score": 3,
            "theme_score": 3,
            "action_score": 3,
            "status": "PASS",
            "drop_reason": None
        }

        # 1. HOOK 체크 (Step 1 또는 ? 포함)
        lines = [l.strip() for l in script.split('\n') if l.strip()]
        first_line = lines[0].lower() if lines else ""
        
        # [BANNED PHRASE CHECK]
        banned_hooks = ["이상한 점이 느껴지지 않아", "이상한 점이 느껴되지 않아", "이상한 점을 느끼껴지지 않아"]
        if any(bh in script for bh in banned_hooks):
            scores["hook_score"] = 1
            scores["status"] = "DROP"
            scores["drop_reason"] = "Banned cliché found in hook"
        elif "[hook]" in script_lower or "step 1" in script_lower or "?" in first_line:
            scores["hook_score"] = 5
        
        # 2. WHY NOW 숫자 및 헤더 체크
        has_numbers = re.search(r'\d+', script)
        if "[why now]" in script_lower or "step 4" in script_lower or "왜 하필 오늘" in script:
            scores["why_now_score"] = 5 if has_numbers else 3
        elif not has_numbers:
            scores["status"] = "DROP"
            scores["drop_reason"] = "Missing numeric data in script"

        # 3. SCENARIO/RISK 체크 (Step 7 또는 시나리오 포함)
        if any(x in script_lower for x in ["[scenario]", "step 7", "시나리오", "risk"]):
            scores["scenario_score"] = 5
        else:
            scores["scenario_score"] = 1
            scores["status"] = "DROP"
            scores["drop_reason"] = "Scenario/Risk section missing"

        # 4. ACTION 체크 (Action 헤더 또는 단계 포함)
        action_indicators = ["[action]", "step 6", "action", "행동 지침", "대응"]
        if any(x in script_lower for x in action_indicators):
            scores["action_score"] = 5
        else:
            scores["action_score"] = 1
            scores["status"] = "DROP"
            scores["drop_reason"] = "ACTION missing or invalid"

        return scores

        return scores

    def _build_evaluation_prompt(self, content: Dict) -> str:
        return f"""
        당신은 유튜브 콘텐츠의 품질을 엄격하게 심사하는 '스크립트 게이트키퍼'입니다. 
        다음 생성된 스크립트를 5개 항목(각 5점 만점)으로 평가하세요.
        
        [콘텐츠 정보]
        타이틀: {content.get('title')}
        타입: {content.get('type')}
        액션: {content.get('action')}
        스크립트 전문:
        {content.get('script')}
        
        [평가 기준]
        1. HOOK (초반 흡입력): 질문/모순으로 시작하는가? (5: 궁금증 유발, 3: 일반적, 1: 뉴스 요약)
        2. WHY NOW (설명력): 숫자와 변화가 포함되어 타이밍이 명확한가? (5: 숫자+변화 명확, 3: 일부 포함, 1: 추상적)
        3. SCENARIO (품질): 시나리오 중 하나를 명확히 선택하여 결론을 내는가? (5: 명확한 선택, 3: 존재만 함, 1: 없음)
        4. THEME/STOCK (연결성): 섹터/종목과 이벤트가 합리적으로 연결되는가? (5: 명확, 3: 섹터만, 1: 없음)
        5. ACTION (행동유도): 무엇을 해야하는지 조건과 행동이 명확한가? (5: 조건+행동 명확, 3: 모호, 1: 없음)
        
        결과는 반드시 다음 JSON 형식으로만 응답하세요:
        {{
            "hook_score": int,
            "why_now_score": int,
            "scenario_score": int,
            "theme_score": int,
            "action_score": int,
            "explanation": "간단한 평가 요약"
        }}
        """
