from src.ui.ui_logic.guards.legacy_usage_meter import hit_legacy
hit_legacy(__name__)
from src.ui.ui_logic.card_builders.narrative_entry_hook_generator import *
