from src.ui.ui_logic.guards.legacy_usage_meter import hit_legacy
hit_legacy(__name__)
from src.ui.ui_logic.narrators.natural_language_summary import *
