# Phase 15 Detection Diagnostics

## Topic: Global Semiconductor Alliance mandates new supply chain standard for 2026, forcing all member firms to comply with immediate effect.
- **Actors**: None
- **Axes**: Policy:POLICY, Capital Flow:FLOW, Supply Chain:CHAIN, Structural Capital:STRUCTURAL
- **Conflict**: Supply_Demand_Gap
- **Final Score**: 63.11

## Topic: 거시경제 이상징후: inflation_pce_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

## Topic: 거시경제 이상징후: rates_fed_funds_fred
- **Actors**: TIER_1:FED, TIER_4:MARKET
- **Axes**: Policy:POLICY, Capital Flow:FLOW, Structural Capital:구조적
- **Conflict**: Tightening_Inflow, Macro_Price_Divergence
- **Final Score**: 84.24

## Topic: 거시경제 이상징후: struct_dart_cb_bw
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

## Topic: 거시경제 이상징후: inflation_kor_cpi_ecos
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 49.59

## Topic: 거시경제 이상징후: comm_wti_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

## Topic: 거시경제 이상징후: struct_dart_disposal
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

## Topic: 거시경제 이상징후: fx_usdkrw_ecos
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

## Topic: 거시경제 이상징후: index_spx_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

## Topic: 거시경제 이상징후: rates_us10y_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:POLICY, Capital Flow:FLOW, Structural Capital:구조적
- **Conflict**: Tightening_Inflow, Macro_Price_Divergence
- **Final Score**: 82.3

## Topic: 거시경제 이상징후: risk_vix_fred
- **Actors**: TIER_3:SK, TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: GeoRisk_Rally, Macro_Price_Divergence
- **Final Score**: 66.07

## Topic: 거시경제 이상징후: liquidity_m2_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Capital Flow:FLOW, Structural Capital:구조적, Liquidity:LIQUIDITY
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

## Topic: 거시경제 이상징후: index_kospi_stooq
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 38.77

## Topic: 거시경제 이상징후: index_nasdaq_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 49.59

## Topic: 거시경제 이상징후: rates_us02y_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:POLICY, Capital Flow:FLOW, Structural Capital:구조적
- **Conflict**: Tightening_Inflow, Macro_Price_Divergence
- **Final Score**: 82.3

## Topic: 거시경제 이상징후: inflation_cpi_fred
- **Actors**: TIER_4:MARKET
- **Axes**: Policy:GOV, Capital Flow:CAPITAL, Structural Capital:STRUCTURAL
- **Conflict**: Macro_Price_Divergence
- **Final Score**: 60.41

