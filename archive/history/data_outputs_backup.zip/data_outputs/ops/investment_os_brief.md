# Investment OS Operational Brief (2026-03-13)

## 🌍 Market Regime
> **긴축 기조 강화 및 유동성 축소 지속**

- **Stance**: `DEFENSIVE_BIAS`
- **Focus**: Rates, Safety, Liquidity, Risk, Policy

## 🚫 Do Not Do
- 무리한 추격 매수
- 레버리지 확대 지양

## 🎯 Priority Topics (Top 3)

### [MONITOR] Global Semiconductor Alliance mandates new supply chain standard for 2026, forcing all member firms to comply with immediate effect.
- **Reasoning**: 상태 정합성 낮음 / 분석 밀도(MONITOR) 기반 대응 우선순위 설정
- **Checklist**:
  - [ ] 지표 추이 및 당국 발언 모니터링

---

### [MONITOR] 거시경제 이상징후: inflation_pce_fred
- **Reasoning**: 상태 정합성 낮음 / 분석 밀도(MONITOR) 기반 대응 우선순위 설정
- **Checklist**:
  - [ ] 지표 추이 및 당국 발언 모니터링

---

### [MONITOR] 거시경제 이상징후: rates_fed_funds_fred
- **Reasoning**: 상태 정합성 낮음 / 분석 밀도(MONITOR) 기반 대응 우선순위 설정
- **Checklist**:
  - [ ] 지표 추이 및 당국 발언 모니터링

| Ticker | Name | Exposure | Risk Note |
|---|---|---|---|
| 105560 | KB금융 | 금리 수익 | 가계 대출 규제 및 충당금 적립 부담 |
| 055550 | 신한지주 | 금리 수익 | 부동산 PF 연체율 관리 리스크 |

---
