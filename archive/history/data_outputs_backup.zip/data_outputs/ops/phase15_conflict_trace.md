# Phase 15 Conflict Trace Report

### Sample 1: Global Semiconductor Alliance mandates new supply chain standard for 2026, forcing all member firms to comply with immediate effect.
- **Raw Input (Norm)**: GLOBAL SEMICONDUCTOR ALLIANCE MANDATES NEW SUPPLY CHAIN STANDARD FOR 2026 FORCING ALL MEMBER FIRMS TO COMPLY WITH IMMEDIATE EFFECT HOIN ENGINE 구조적 분석 결과 STRUCTURAL REDEFINITION 유형의 패턴이 감지되었습니다 드라이버 IN...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 2: 거시경제 이상징후: inflation_pce_fred
- **Raw Input (Norm)**: 거시경제 이상징후 INFLATION PCE FRED HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 3: 거시경제 이상징후: rates_fed_funds_fred
- **Raw Input (Norm)**: 거시경제 이상징후 RATES FED FUNDS FRED HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 4: 거시경제 이상징후: struct_dart_cb_bw
- **Raw Input (Norm)**: 거시경제 이상징후 STRUCT DART CB BW HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 5: 거시경제 이상징후: inflation_kor_cpi_ecos
- **Raw Input (Norm)**: 거시경제 이상징후 INFLATION KOR CPI ECOS HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 6: 거시경제 이상징후: comm_wti_fred
- **Raw Input (Norm)**: 거시경제 이상징후 COMM WTI FRED HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 7: 거시경제 이상징후: struct_dart_disposal
- **Raw Input (Norm)**: 거시경제 이상징후 STRUCT DART DISPOSAL HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: ['Macro_Price_Divergence']
- **Reason for Result**: Conflict triggered by patterns: ['Macro_Price_Divergence']

### Sample 8: 거시경제 이상징후: fx_usdkrw_ecos
- **Raw Input (Norm)**: 거시경제 이상징후 FX USDKRW ECOS HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 9: 거시경제 이상징후: index_spx_fred
- **Raw Input (Norm)**: 거시경제 이상징후 INDEX SPX FRED HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

### Sample 10: 거시경제 이상징후: rates_us10y_fred
- **Raw Input (Norm)**: 거시경제 이상징후 RATES US10Y FRED HOIN ENGINE 구조적 분석 결과 HOIN ANOMALY 유형의 패턴이 감지되었습니다 드라이버 MACRO MARKET...
- **Escalated**: False
- **Matched Patterns**: NONE
- **Reason for Result**: No conflict patterns matched semantic conditions.

